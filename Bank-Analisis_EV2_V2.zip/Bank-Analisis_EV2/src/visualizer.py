import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

class BankDataVisualizer:
    def __init__(self, df):
        self.df = df
        sns.set_theme(style="whitegrid", palette="muted")
        
    def seccion_1_variable_objetivo(self):
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        
        sns.countplot(data=self.df, x='suscripcion', ax=axes[0], palette='Set2')
        axes[0].set_title('1. Distribución de Suscripciones (Sí/No)')
        axes[0].set_xlabel('¿Suscribió depósito a plazo?')
        axes[0].set_ylabel('Cantidad de Clientes')
        
        y_counts = self.df['suscripcion'].value_counts()
        axes[1].pie(y_counts, labels=y_counts.index, autopct='%1.1f%%', colors=['#ff9999', '#66b3ff'], startangle=90)
        axes[1].set_title('2. Porcentaje de Conversión General')
        
        plt.tight_layout()
        plt.show()

    def seccion_2_demografia(self):
        fig, axes = plt.subplots(3, 2, figsize=(16, 18))
        
        sns.histplot(data=self.df, x='edad', bins=20, kde=True, ax=axes[0, 0], color='skyblue')
        axes[0, 0].set_title('3. Distribución de Edades de Clientes')
        axes[0, 0].set_xlabel('Edad')
        axes[0, 0].set_ylabel('Frecuencia')
        
        sns.countplot(data=self.df, y='trabajo', ax=axes[0, 1], order=self.df['trabajo'].value_counts().index, palette='viridis')
        axes[0, 1].set_title('4. Clientes por Tipo de Trabajo')
        axes[0, 1].set_xlabel('Cantidad de Clientes')
        axes[0, 1].set_ylabel('Tipo de Trabajo')
        
        sns.countplot(data=self.df, y='educacion', ax=axes[1, 0], order=self.df['educacion'].value_counts().index, palette='magma')
        axes[1, 0].set_title('5. Clientes por Nivel Educativo')
        axes[1, 0].set_xlabel('Cantidad de Clientes')
        axes[1, 0].set_ylabel('Educación')
        
        sns.boxplot(data=self.df, x='suscripcion', y='edad', ax=axes[1, 1], palette='Set2')
        axes[1, 1].set_title('6. Relación entre Edad y Suscripción')
        axes[1, 1].set_xlabel('¿Suscribió depósito?')
        axes[1, 1].set_ylabel('Edad')
        
        job_y = pd.crosstab(self.df['trabajo'], self.df['suscripcion'], normalize='index')
        job_y.plot(kind='bar', stacked=True, ax=axes[2, 0], color=['#ff9999','#66b3ff'])
        axes[2, 0].set_title('7. Tasa de Conversión por Trabajo')
        axes[2, 0].set_ylabel('Proporción')
        axes[2, 0].set_xlabel('Tipo de Trabajo')
        
        marital_y = pd.crosstab(self.df['estado_civil'], self.df['suscripcion'], normalize='index')
        marital_y.plot(kind='bar', stacked=True, ax=axes[2, 1], color=['#ff9999','#66b3ff'])
        axes[2, 1].set_title('8. Tasa de Conversión por Estado Civil')
        axes[2, 1].set_ylabel('Proporción')
        axes[2, 1].set_xlabel('Estado Civil')
        
        plt.tight_layout()
        plt.show()

    def seccion_3_estrategia(self):
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        sns.histplot(data=self.df, x='campana', bins=10, ax=axes[0, 0], color='coral')
        axes[0, 0].set_title('9. Contactos Realizados durante la Campaña')
        axes[0, 0].set_xlabel('Número de contactos')
        axes[0, 0].set_ylabel('Frecuencia')
        
        sns.countplot(data=self.df, x='contacto', hue='suscripcion', ax=axes[0, 1], palette='Set1')
        axes[0, 1].set_title('10. Impacto del Canal de Contacto en la Conversión')
        axes[0, 1].set_xlabel('Vía de Contacto')
        axes[0, 1].set_ylabel('Cantidad de Clientes')
        
        meses_orden = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']
        sns.countplot(data=self.df, x='mes', order=meses_orden, ax=axes[1, 0], palette='coolwarm')
        axes[1, 0].set_title('11. Volumen de Interacciones por Mes')
        axes[1, 0].set_xlabel('Mes')
        axes[1, 0].set_ylabel('Cantidad de Interacciones')
        
        sns.countplot(data=self.df, x='resultado_anterior', hue='suscripcion', ax=axes[1, 1], palette='Set2')
        axes[1, 1].set_title('12. Resultado Campaña Anterior vs Conversión Actual')
        axes[1, 1].set_xlabel('Resultado Histórico')
        axes[1, 1].set_ylabel('Cantidad de Clientes')
        
        plt.tight_layout()
        plt.show()

    def seccion_4_contexto_economico(self):
        fig, axes = plt.subplots(1, 3, figsize=(18, 5))
        
        sns.boxplot(data=self.df, x='suscripcion', y='euribor_3m', ax=axes[0], palette='Set3')
        axes[0].set_title('13. Tasa Euribor (3 meses) vs Suscripción')
        axes[0].set_xlabel('¿Suscribió depósito?')
        axes[0].set_ylabel('Tasa Euribor')
        
        sns.scatterplot(data=self.df, x='idx_precios_cons', y='idx_conf_cons', hue='suscripcion', alpha=0.6, ax=axes[1])
        axes[1].set_title('14. Índices Económicos: Precios vs Confianza')
        axes[1].set_xlabel('Índice de Precios al Consumidor')
        axes[1].set_ylabel('Índice de Confianza del Consumidor')
        
        num_df = self.df.select_dtypes(include=['int64', 'float64'])
        corr = num_df.corr()
        sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm', ax=axes[2], cbar=False)
        axes[2].set_title('15. Matriz de Correlación Numérica')
        
        plt.tight_layout()
        plt.show()
        