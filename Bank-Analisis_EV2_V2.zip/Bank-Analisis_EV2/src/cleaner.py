import pandas as pd

class BankDataCleaner:
    def __init__(self, filepath):
        print(f"Cargando datos desde: {filepath}")
        self.df = pd.read_csv(filepath, sep=';')
        
    def traducir_al_espanol(self):
        """Traduce las columnas y los valores internos del dataset al español."""
        # 1. Renombrar Columnas
        columnas_espanol = {
            'age': 'edad', 'job': 'trabajo', 'marital': 'estado_civil', 
            'education': 'educacion', 'default': 'mora', 'housing': 'vivienda', 
            'loan': 'prestamo', 'contact': 'contacto', 'month': 'mes', 
            'day_of_week': 'dia_de_la_semana', 'duration': 'duracion', 
            'campaign': 'campana', 'pdays': 'dias_previos', 'previous': 'contactos_anteriores', 
            'poutcome': 'resultado_anterior', 'emp.var.rate': 'tasa_var_empleo', 
            'cons.price.idx': 'idx_precios_cons', 'cons.conf.idx': 'idx_conf_cons', 
            'euribor3m': 'euribor_3m', 'nr.employed': 'num_empleados', 'y': 'suscripcion'
        }
        self.df.rename(columns=columnas_espanol, inplace=True)

        # 2. Traducir valores de las columnas categóricas
        dicc_trabajo = {'admin.': 'administrador', 'blue-collar': 'obrero', 'entrepreneur': 'empresario', 'housemaid': 'empleado doméstico', 'management': 'gerente', 'retired': 'jubilado', 'self-employed': 'autónomo', 'services': 'servicios', 'student': 'estudiante', 'technician': 'técnico', 'unemployed': 'desempleado', 'unknown': 'desconocido'}
        dicc_estado_civil = {'divorced': 'divorciado', 'married': 'casado', 'single': 'soltero', 'unknown': 'desconocido'}
        dicc_educacion = {'basic.4y': 'básico.4a', 'basic.6y': 'básico.6a', 'basic.9y': 'básico.9a', 'high.school': 'bachillerato', 'illiterate': 'analfabeto', 'professional.course': 'curso profesional', 'university.degree': 'título universitario', 'unknown': 'desconocido'}
        dicc_binario = {'no': 'no', 'yes': 'sí', 'unknown': 'desconocido'}
        dicc_contacto = {'cellular': 'celular', 'telephone': 'teléfono'}
        dicc_mes = {'jan': 'ene', 'feb': 'feb', 'mar': 'mar', 'apr': 'abr', 'may': 'may', 'jun': 'jun', 'jul': 'jul', 'aug': 'ago', 'sep': 'sep', 'oct': 'oct', 'nov': 'nov', 'dec': 'dic'}
        dicc_resultado = {'failure': 'fracaso', 'nonexistent': 'inexistente', 'success': 'éxito'}

        self.df['trabajo'] = self.df['trabajo'].map(dicc_trabajo).fillna(self.df['trabajo'])
        self.df['estado_civil'] = self.df['estado_civil'].map(dicc_estado_civil).fillna(self.df['estado_civil'])
        self.df['educacion'] = self.df['educacion'].map(dicc_educacion).fillna(self.df['educacion'])
        self.df['mora'] = self.df['mora'].map(dicc_binario).fillna(self.df['mora'])
        self.df['vivienda'] = self.df['vivienda'].map(dicc_binario).fillna(self.df['vivienda'])
        self.df['prestamo'] = self.df['prestamo'].map(dicc_binario).fillna(self.df['prestamo'])
        self.df['suscripcion'] = self.df['suscripcion'].map(dicc_binario).fillna(self.df['suscripcion'])
        self.df['contacto'] = self.df['contacto'].map(dicc_contacto).fillna(self.df['contacto'])
        self.df['mes'] = self.df['mes'].map(dicc_mes).fillna(self.df['mes'])
        self.df['resultado_anterior'] = self.df['resultado_anterior'].map(dicc_resultado).fillna(self.df['resultado_anterior'])

        print("Dataset completamente traducido al español.")
        return self
        
    def eliminar_irrelevantes(self):
        # Ahora eliminamos 'duracion' en lugar de 'duration'
        if 'duracion' in self.df.columns:
            self.df = self.df.drop(columns=['duracion'])
            print("Columna 'duracion' eliminada por causar sesgos éticos y predictivos.")
        return self
        
    def tratar_valores_desconocidos(self):
        # Ahora buscamos la palabra en español
        self.df = self.df.replace('desconocido', pd.NA)
        print("Valores 'desconocido' convertidos a nulos reales (NA).")
        return self
        
    def imputar_nulos_categoricos(self):
        cols_texto = self.df.select_dtypes(include=['object']).columns
        for col in cols_texto:
            if not self.df[col].mode().empty:
                valor_mas_frecuente = self.df[col].mode()[0]
                self.df[col] = self.df[col].fillna(valor_mas_frecuente)
        print("Valores nulos imputados con la moda.")
        return self
        
    def manejar_outliers(self):
        cols_numericas = self.df.select_dtypes(include=['int64', 'float64']).columns
        for col in cols_numericas:
            Q1 = self.df[col].quantile(0.25)
            Q3 = self.df[col].quantile(0.75)
            IQR = Q3 - Q1
            limite_inferior = Q1 - 1.5 * IQR
            limite_superior = Q3 + 1.5 * IQR
            self.df[col] = self.df[col].clip(lower=limite_inferior, upper=limite_superior)
        print("Outliers manejados mediante Capping.")
        return self
        
    def eliminar_duplicados(self):
        filas_antes = len(self.df)
        self.df = self.df.drop_duplicates()
        filas_despues = len(self.df)
        print(f"Duplicados eliminados: {filas_antes - filas_despues} filas.")
        return self
        
    def obtener_dataframe(self):
        return self.df
        
    def guardar_datos(self, output_path):
        self.df.to_csv(output_path, index=False)
        print(f"Datos limpios 100% en español guardados en: {output_path}")

    def codificar_categoricas(self):
        """Convierte variables de texto en columnas numéricas binarias (One-Hot Encoding)."""
        # Seleccionamos las columnas que son de tipo texto
        cols_categoricas = self.df.select_dtypes(include=['object']).columns
        
        # get_dummies convierte cada categoría en una nueva columna de True/False (o 1/0)
        # drop_first=True evita la trampa de las variables ficticias (colinealidad)
        self.df = pd.get_dummies(self.df, columns=cols_categoricas, drop_first=True)
        
        # Convertimos los booleanos a enteros (1 y 0) por compatibilidad
        columnas_booleanas = self.df.select_dtypes(include=['bool']).columns
        self.df[columnas_booleanas] = self.df[columnas_booleanas].astype(int)
        
        print("Variables categóricas codificadas exitosamente.")
        return self

    def escalar_numericas(self):
        """Escala las variables numéricas originales a un rango entre 0 y 1."""
        from sklearn.preprocessing import MinMaxScaler
        scaler = MinMaxScaler()
        
        # Seleccionamos solo las columnas numéricas que no sean binarias (las originales)
        # Como ya codificamos, filtramos aquellas que tengan valores mayores a 1 o menores a 0
        cols_numericas = self.df.select_dtypes(include=['int32', 'int64', 'float64']).columns
        cols_a_escalar = [col for col in cols_numericas if self.df[col].nunique() > 2]
        
        if cols_a_escalar:
            self.df[cols_a_escalar] = scaler.fit_transform(self.df[cols_a_escalar])
            print("Variables numéricas escaladas (MinMaxScaler aplicado).")
            
        return self
    
